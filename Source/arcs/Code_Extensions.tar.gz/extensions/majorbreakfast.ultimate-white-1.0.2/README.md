# Ultimate White

_Visual Studio Code Color Theme_

Dark Mode users beware! This is not the color theme for you! This is the color theme that uses pure and perfect `#ffffff` white as background for everything. No dark activity bar in this theme - just white backgrounds everywhere, as it should be.

The `material-icon-theme` is recommended as icon theme.

![Ultimate White Visual Studio Code theme screenshot](https://github.com/MajorBreakfast/ultimate-white/raw/master/images/screenshot.png)
